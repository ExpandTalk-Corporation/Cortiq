<?php
/**
 * Plugin Name: CortIQ Analytics
 * Plugin URI: https://cortiq.se
 * Description: Analytics for the agentic web. Classifies AI crawlers and agent fetches (GPTBot, ClaudeBot, ChatGPT-User, PerplexityBot…) and measures human visitors after consent — cookieless mode, heatmaps, conversions and a built-in consent banner.
 * Version: 5.5.21
 * Author: CortIQ
 * Author URI: https://cortiq.se
 * Requires at least: 5.6
 * Tested up to: 6.8
 * Requires PHP: 7.4
 * License: GPL v2 or later
 * Text Domain: cortiq
 */

// Block direct access
if ( ! defined( 'ABSPATH' ) ) exit;

// Prevent double-loading
if ( defined( 'CORTIQ_LOADED' ) ) return;
define( 'CORTIQ_LOADED', true );

// Shared with public/spa-tracking.js (CORTIQ_VERSION) — also the ?ver= cache-bust for it.
define( 'CORTIQ_VERSION',    '5.5.21' );
define( 'CORTIQ_OPTION_KEY', 'cortiq_options' );
// Supabase Edge Functions base — used for the GDPR consent ledger (store-consent).
define( 'CORTIQ_API',        'https://cxmkdtgfocgbfizawlwa.supabase.co/functions/v1' );
define( 'CORTIQ_GEO_API',    'https://cortiq-geo.cortiq.workers.dev' );
// Server-side agent measurement: honeypot path and AI-bot pre-filter (CortIQ's registry).
// Keep CORTIQ_AGENT_UA in sync with AGENT_UA in public/cortiq-server.mjs (test-enforced).
define( 'CORTIQ_TRAP_PATH',  '/cortiq-trap/' );
define( 'CORTIQ_AGENT_UA',   '/GPTBot|ChatGPT|OAI-SearchBot|Claude-User|Claude-SearchBot|ClaudeBot|anthropic-ai|Perplexity|Google-Extended|GoogleOther|Googlebot|bingbot|BingPreview|Meta-ExternalAgent|FacebookBot|facebookexternalhit|Applebot|YouBot|DuckAssistBot|Grok|Amazonbot|Bytespider|CCBot|Diffbot|cohere-ai|DeepSeek|MistralAI/i' );

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

function cortiq_defaults() {
    return array(
        'site_id'               => '',   // UUID from CortIQ dashboard
        'tracking_id'           => '',   // tk_xxx (legacy, kept for reference)
        'ga4_id'                => '',   // Google Analytics 4 Measurement ID (G-XXXXXXXXXX)
        'tracking_enabled'      => true,
        'gdpr_enabled'          => true,
        'anonymize_ip'          => true,
        'excluded_roles'        => array( 'administrator' ),
        'accent_color'          => '#6366f1',
        'tracking_mode'         => 'full',   // 'cookieless' (no fingerprint/profile) | 'full'
        'cookieless_memory_only'=> false,    // cookieless: keep the session id in memory only (no sessionStorage)
        'banner_language'       => 'auto',   // 'auto' (WP locale) | a code from cortiq_banner_languages()
        'consent_mode'          => 'basic',  // GA4 Consent Mode: 'basic' | 'advanced'
        'policy_version'        => '1',      // change to re-prompt every visitor
        'reprompt_cooldown_days'=> 365,      // how long an accepted choice is respected before re-asking
        'reprompt_reject_days'  => 180,      // how long a necessary-only choice is respected before re-asking
        'consent_region'        => 'eea',    // 'eea' (region-scoped defaults) | 'global'
        'geo_gating'            => false,    // show the banner only to EEA/UK/CH visitors
        'server_side'           => true,     // server-side AI agent measurement (needs tracking_id)
        'aggregate'             => false,   // consent-free aggregate counts (assets/cortiq-aggregate.js)
    );
}

function cortiq_options() {
    $saved = get_option( CORTIQ_OPTION_KEY, array() );

    // Migrate legacy key from class-based plugin versions (< 5.1)
    if ( empty( $saved['ga4_id'] ) && ! empty( $saved['ga_measurement_id'] ) ) {
        $saved['ga4_id'] = $saved['ga_measurement_id'];
    }

    return wp_parse_args( $saved, cortiq_defaults() );
}

// ─────────────────────────────────────────────────────────────────────────────
// i18n — banner strings (flat dictionary; add a language = add a key)
// ─────────────────────────────────────────────────────────────────────────────

function cortiq_banner_lang( $opts ) {
    $choice = isset( $opts['banner_language'] ) ? $opts['banner_language'] : 'auto';
    if ( 'auto' === $choice ) {
        $loc = strtolower( (string) get_locale() );
        // Norwegian locales are nb_NO, nn_NO or no; all get the bokmål texts.
        if ( preg_match( '/^(nb|nn|no)(_|$)/', $loc ) ) return 'nb';
        foreach ( array( 'sv', 'de', 'fr', 'pt', 'nl', 'da', 'fi', 'pl', 'it', 'es', 'is' ) as $code ) {
            if ( 0 === strpos( $loc, $code ) ) return $code;
        }
        return 'en';
    }
    return in_array( $choice, cortiq_banner_languages(), true ) ? $choice : 'en';
}

function cortiq_banner_languages() {
    return array( 'en', 'sv', 'de', 'fr', 'pt', 'nl', 'nb', 'da', 'fi', 'pl', 'it', 'es', 'is' );
}

function cortiq_banner_strings( $lang ) {
    $s = array(
        'en' => array(
            'title'          => '🍪 Cookie settings',
            'intro'          => 'We want to understand what readers enjoy, and show you relevant content. Choose what you allow.',
            'necessary'      => 'Necessary',
            'necessary_desc' => 'Required for the site to work. Always on.',
            'preferences'    => 'Preferences',
            'preferences_desc' => 'Remembers choices like language and layout.',
            'statistics'     => 'Statistics',
            'statistics_desc' => 'Helps us see which pages and content people like.',
            'marketing'      => 'Marketing',
            'marketing_desc' => 'Used to show relevant ads and measure campaigns.',
            'show_details'   => 'Show details',
            'hide_details'   => 'Hide details',
            'accept_all'     => 'Accept all',
            'only_necessary' => 'Only necessary',
            'save'           => 'Save selection',
            'reopen'         => 'Cookie settings',
            'consent_date'   => 'Consent date',
            'consent_id'     => 'Consent ID',
            'categories'     => 'Categories',
            'close'          => 'Close',
            'gpc'            => 'Your browser sends Global Privacy Control (GPC), so marketing is turned off here.',
        ),
        'sv' => array(
            'title'          => '🍪 Cookie-inställningar',
            'intro'          => 'Vi vill förstå vad läsarna gillar och visa dig relevant innehåll. Välj vad du tillåter.',
            'necessary'      => 'Nödvändiga',
            'necessary_desc' => 'Krävs för att sajten ska fungera. Alltid på.',
            'preferences'    => 'Preferenser',
            'preferences_desc' => 'Kommer ihåg val som språk och layout.',
            'statistics'     => 'Statistik',
            'statistics_desc' => 'Hjälper oss se vilka sidor och innehåll besökarna gillar.',
            'marketing'      => 'Marknadsföring',
            'marketing_desc' => 'Används för att visa relevanta annonser och mäta kampanjer.',
            'show_details'   => 'Visa detaljer',
            'hide_details'   => 'Dölj detaljer',
            'accept_all'     => 'Acceptera alla',
            'only_necessary' => 'Endast nödvändiga',
            'save'           => 'Spara val',
            'reopen'         => 'Cookie-inställningar',
            'consent_date'   => 'Samtyckesdatum',
            'consent_id'     => 'Samtyckes-ID',
            'categories'     => 'Kategorier',
            'close'          => 'Stäng',
            'gpc'            => 'Din webbläsare skickar Global Privacy Control (GPC). Därför är marknadsföring avstängd här.',
        ),
        'de' => array(
            'title'          => '🍪 Cookie-Einstellungen',
            'intro'          => 'Wir möchten verstehen, was Leser mögen, und Ihnen relevante Inhalte zeigen. Wählen Sie, was Sie erlauben.',
            'necessary'      => 'Notwendig',
            'necessary_desc' => 'Für den Betrieb der Website erforderlich. Immer aktiv.',
            'preferences'    => 'Präferenzen',
            'preferences_desc' => 'Merkt sich Einstellungen wie Sprache und Layout.',
            'statistics'     => 'Statistik',
            'statistics_desc' => 'Hilft uns zu sehen, welche Seiten und Inhalte gefallen.',
            'marketing'      => 'Marketing',
            'marketing_desc' => 'Für relevante Werbung und die Messung von Kampagnen.',
            'show_details'   => 'Details anzeigen',
            'hide_details'   => 'Details ausblenden',
            'accept_all'     => 'Alle akzeptieren',
            'only_necessary' => 'Nur notwendige',
            'save'           => 'Auswahl speichern',
            'reopen'         => 'Cookie-Einstellungen',
            'consent_date'   => 'Einwilligungsdatum',
            'consent_id'     => 'Einwilligungs-ID',
            'categories'     => 'Kategorien',
            'close'          => 'Schließen',
            'gpc'            => 'Ihr Browser sendet Global Privacy Control (GPC). Marketing ist deshalb hier deaktiviert.',
        ),
        'fr' => array(
            'title'          => '🍪 Paramètres des cookies',
            'intro'          => 'Nous voulons comprendre ce que les lecteurs apprécient et vous proposer un contenu pertinent. Choisissez ce que vous autorisez.',
            'necessary'      => 'Nécessaires',
            'necessary_desc' => 'Requis au fonctionnement du site. Toujours actifs.',
            'preferences'    => 'Préférences',
            'preferences_desc' => 'Mémorise vos choix comme la langue et la mise en page.',
            'statistics'     => 'Statistiques',
            'statistics_desc' => 'Nous aide à voir quelles pages et quels contenus plaisent.',
            'marketing'      => 'Marketing',
            'marketing_desc' => 'Utilisé pour afficher des publicités pertinentes et mesurer les campagnes.',
            'show_details'   => 'Afficher les détails',
            'hide_details'   => 'Masquer les détails',
            'accept_all'     => 'Tout accepter',
            'only_necessary' => 'Nécessaires uniquement',
            'save'           => 'Enregistrer la sélection',
            'reopen'         => 'Paramètres des cookies',
            'consent_date'   => 'Date du consentement',
            'consent_id'     => 'ID de consentement',
            'categories'     => 'Catégories',
            'close'          => 'Fermer',
            'gpc'            => 'Votre navigateur envoie le signal Global Privacy Control (GPC) : le marketing est donc désactivé ici.',
        ),
        'pt' => array(
            'title'          => '🍪 Definições de cookies',
            'intro'          => 'Queremos perceber o que os leitores gostam e mostrar-lhe conteúdo relevante. Escolha o que permite.',
            'necessary'      => 'Necessários',
            'necessary_desc' => 'Necessários para o funcionamento do site. Sempre ativos.',
            'preferences'    => 'Preferências',
            'preferences_desc' => 'Memoriza escolhas como idioma e esquema.',
            'statistics'     => 'Estatísticas',
            'statistics_desc' => 'Ajuda-nos a ver que páginas e conteúdos as pessoas preferem.',
            'marketing'      => 'Marketing',
            'marketing_desc' => 'Usado para mostrar anúncios relevantes e medir campanhas.',
            'show_details'   => 'Mostrar detalhes',
            'hide_details'   => 'Ocultar detalhes',
            'accept_all'     => 'Aceitar tudo',
            'only_necessary' => 'Apenas necessários',
            'save'           => 'Guardar seleção',
            'reopen'         => 'Definições de cookies',
            'consent_date'   => 'Data do consentimento',
            'consent_id'     => 'ID de consentimento',
            'categories'     => 'Categorias',
            'close'          => 'Fechar',
            'gpc'            => 'O seu navegador envia o sinal Global Privacy Control (GPC), por isso o marketing está desativado aqui.',
        ),
        'nl' => array(
            'title'          => '🍪 Cookie-instellingen',
            'intro'          => 'We willen begrijpen wat lezers waarderen en je relevante inhoud tonen. Kies wat je toestaat.',
            'necessary'      => 'Noodzakelijk',
            'necessary_desc' => 'Nodig om de site te laten werken. Altijd aan.',
            'preferences'    => 'Voorkeuren',
            'preferences_desc' => 'Onthoudt keuzes zoals taal en indeling.',
            'statistics'     => 'Statistieken',
            'statistics_desc' => 'Helpt ons te zien welke pagina’s en inhoud bezoekers waarderen.',
            'marketing'      => 'Marketing',
            'marketing_desc' => 'Gebruikt om relevante advertenties te tonen en campagnes te meten.',
            'show_details'   => 'Details tonen',
            'hide_details'   => 'Details verbergen',
            'accept_all'     => 'Alles accepteren',
            'only_necessary' => 'Alleen noodzakelijk',
            'save'           => 'Selectie opslaan',
            'reopen'         => 'Cookie-instellingen',
            'consent_date'   => 'Datum toestemming',
            'consent_id'     => 'Toestemmings-ID',
            'categories'     => 'Categorieën',
            'close'          => 'Sluiten',
            'gpc'            => 'Je browser verstuurt Global Privacy Control (GPC). Daarom is marketing hier uitgeschakeld.',
        ),
        'nb' => array(
            'title'          => '🍪 Cookie-innstillinger',
            'intro'          => 'Vi vil forstå hva leserne liker og vise deg relevant innhold. Velg hva du tillater.',
            'necessary'      => 'Nødvendige',
            'necessary_desc' => 'Kreves for at nettstedet skal fungere. Alltid på.',
            'preferences'    => 'Preferanser',
            'preferences_desc' => 'Husker valg som språk og oppsett.',
            'statistics'     => 'Statistikk',
            'statistics_desc' => 'Hjelper oss å se hvilke sider og hvilket innhold besøkende liker.',
            'marketing'      => 'Markedsføring',
            'marketing_desc' => 'Brukes til å vise relevante annonser og måle kampanjer.',
            'show_details'   => 'Vis detaljer',
            'hide_details'   => 'Skjul detaljer',
            'accept_all'     => 'Godta alle',
            'only_necessary' => 'Bare nødvendige',
            'save'           => 'Lagre valg',
            'reopen'         => 'Cookie-innstillinger',
            'consent_date'   => 'Samtykkedato',
            'consent_id'     => 'Samtykke-ID',
            'categories'     => 'Kategorier',
            'close'          => 'Lukk',
            'gpc'            => 'Nettleseren din sender Global Privacy Control (GPC). Markedsføring er derfor slått av her.',
        ),
        'da' => array(
            'title'          => '🍪 Cookie-indstillinger',
            'intro'          => 'Vi vil gerne forstå, hvad læserne synes om, og vise dig relevant indhold. Vælg, hvad du tillader.',
            'necessary'      => 'Nødvendige',
            'necessary_desc' => 'Kræves for at sitet virker. Altid slået til.',
            'preferences'    => 'Præferencer',
            'preferences_desc' => 'Husker valg som sprog og layout.',
            'statistics'     => 'Statistik',
            'statistics_desc' => 'Hjælper os med at se, hvilke sider og hvilket indhold besøgende synes om.',
            'marketing'      => 'Markedsføring',
            'marketing_desc' => 'Bruges til at vise relevante annoncer og måle kampagner.',
            'show_details'   => 'Vis detaljer',
            'hide_details'   => 'Skjul detaljer',
            'accept_all'     => 'Accepter alle',
            'only_necessary' => 'Kun nødvendige',
            'save'           => 'Gem valg',
            'reopen'         => 'Cookie-indstillinger',
            'consent_date'   => 'Samtykkedato',
            'consent_id'     => 'Samtykke-ID',
            'categories'     => 'Kategorier',
            'close'          => 'Luk',
            'gpc'            => 'Din browser sender Global Privacy Control (GPC). Markedsføring er derfor slået fra her.',
        ),
        'fi' => array(
            'title'          => '🍪 Evästeasetukset',
            'intro'          => 'Haluamme ymmärtää, mistä lukijat pitävät, ja näyttää sinulle kiinnostavaa sisältöä. Valitse, mitä sallit.',
            'necessary'      => 'Välttämättömät',
            'necessary_desc' => 'Tarvitaan sivuston toimintaan. Aina käytössä.',
            'preferences'    => 'Mieltymykset',
            'preferences_desc' => 'Muistaa valinnat, kuten kielen ja asettelun.',
            'statistics'     => 'Tilastot',
            'statistics_desc' => 'Auttaa meitä näkemään, mistä sivuista ja sisällöstä kävijät pitävät.',
            'marketing'      => 'Markkinointi',
            'marketing_desc' => 'Käytetään kiinnostavien mainosten näyttämiseen ja kampanjoiden mittaamiseen.',
            'show_details'   => 'Näytä tiedot',
            'hide_details'   => 'Piilota tiedot',
            'accept_all'     => 'Hyväksy kaikki',
            'only_necessary' => 'Vain välttämättömät',
            'save'           => 'Tallenna valinnat',
            'reopen'         => 'Evästeasetukset',
            'consent_date'   => 'Suostumuksen päivämäärä',
            'consent_id'     => 'Suostumustunnus',
            'categories'     => 'Luokat',
            'close'          => 'Sulje',
            'gpc'            => 'Selaimesi lähettää Global Privacy Control (GPC) -signaalin, joten markkinointi on tässä pois päältä.',
        ),
        'pl' => array(
            'title'          => '🍪 Ustawienia plików cookie',
            'intro'          => 'Chcemy wiedzieć, co podoba się czytelnikom, i pokazywać Ci trafne treści. Wybierz, na co się zgadzasz.',
            'necessary'      => 'Niezbędne',
            'necessary_desc' => 'Wymagane do działania strony. Zawsze włączone.',
            'preferences'    => 'Preferencje',
            'preferences_desc' => 'Zapamiętują wybory, takie jak język i układ.',
            'statistics'     => 'Statystyki',
            'statistics_desc' => 'Pomagają nam zobaczyć, które strony i treści podobają się odwiedzającym.',
            'marketing'      => 'Marketing',
            'marketing_desc' => 'Służą do wyświetlania trafnych reklam i mierzenia kampanii.',
            'show_details'   => 'Pokaż szczegóły',
            'hide_details'   => 'Ukryj szczegóły',
            'accept_all'     => 'Akceptuj wszystkie',
            'only_necessary' => 'Tylko niezbędne',
            'save'           => 'Zapisz wybór',
            'reopen'         => 'Ustawienia plików cookie',
            'consent_date'   => 'Data zgody',
            'consent_id'     => 'ID zgody',
            'categories'     => 'Kategorie',
            'close'          => 'Zamknij',
            'gpc'            => 'Twoja przeglądarka wysyła sygnał Global Privacy Control (GPC), dlatego marketing jest tu wyłączony.',
        ),
        'it' => array(
            'title'          => '🍪 Impostazioni dei cookie',
            'intro'          => 'Vogliamo capire cosa apprezzano i lettori e mostrarti contenuti pertinenti. Scegli cosa consentire.',
            'necessary'      => 'Necessari',
            'necessary_desc' => 'Indispensabili per il funzionamento del sito. Sempre attivi.',
            'preferences'    => 'Preferenze',
            'preferences_desc' => 'Ricordano scelte come la lingua e il layout.',
            'statistics'     => 'Statistiche',
            'statistics_desc' => 'Ci aiutano a capire quali pagine e contenuti piacciono ai visitatori.',
            'marketing'      => 'Marketing',
            'marketing_desc' => 'Usati per mostrare annunci pertinenti e misurare le campagne.',
            'show_details'   => 'Mostra dettagli',
            'hide_details'   => 'Nascondi dettagli',
            'accept_all'     => 'Accetta tutti',
            'only_necessary' => 'Solo necessari',
            'save'           => 'Salva selezione',
            'reopen'         => 'Impostazioni dei cookie',
            'consent_date'   => 'Data del consenso',
            'consent_id'     => 'ID del consenso',
            'categories'     => 'Categorie',
            'close'          => 'Chiudi',
            'gpc'            => 'Il tuo browser invia il segnale Global Privacy Control (GPC), quindi il marketing qui è disattivato.',
        ),
        'es' => array(
            'title'          => '🍪 Configuración de cookies',
            'intro'          => 'Queremos entender qué les gusta a los lectores y mostrarte contenido relevante. Elige lo que permites.',
            'necessary'      => 'Necesarias',
            'necessary_desc' => 'Imprescindibles para que el sitio funcione. Siempre activas.',
            'preferences'    => 'Preferencias',
            'preferences_desc' => 'Recuerdan opciones como el idioma y el diseño.',
            'statistics'     => 'Estadísticas',
            'statistics_desc' => 'Nos ayudan a ver qué páginas y contenidos gustan a los visitantes.',
            'marketing'      => 'Marketing',
            'marketing_desc' => 'Se usan para mostrar anuncios relevantes y medir campañas.',
            'show_details'   => 'Mostrar detalles',
            'hide_details'   => 'Ocultar detalles',
            'accept_all'     => 'Aceptar todas',
            'only_necessary' => 'Solo necesarias',
            'save'           => 'Guardar selección',
            'reopen'         => 'Configuración de cookies',
            'consent_date'   => 'Fecha del consentimiento',
            'consent_id'     => 'ID del consentimiento',
            'categories'     => 'Categorías',
            'close'          => 'Cerrar',
            'gpc'            => 'Tu navegador envía la señal Global Privacy Control (GPC), por lo que el marketing está desactivado aquí.',
        ),
        'is' => array(
            'title'          => '🍪 Vafrakökustillingar',
            'intro'          => 'Við viljum skilja hvað lesendum líkar og sýna þér viðeigandi efni. Veldu hvað þú leyfir.',
            'necessary'      => 'Nauðsynlegar',
            'necessary_desc' => 'Nauðsynlegar til að vefurinn virki. Alltaf virkar.',
            'preferences'    => 'Kjörstillingar',
            'preferences_desc' => 'Muna val eins og tungumál og útlit.',
            'statistics'     => 'Tölfræði',
            'statistics_desc' => 'Hjálpa okkur að sjá hvaða síður og efni gestum líkar.',
            'marketing'      => 'Markaðssetning',
            'marketing_desc' => 'Notaðar til að sýna viðeigandi auglýsingar og mæla herferðir.',
            'show_details'   => 'Sýna nánar',
            'hide_details'   => 'Fela nánar',
            'accept_all'     => 'Samþykkja allar',
            'only_necessary' => 'Aðeins nauðsynlegar',
            'save'           => 'Vista val',
            'reopen'         => 'Vafrakökustillingar',
            'consent_date'   => 'Dagsetning samþykkis',
            'consent_id'     => 'Auðkenni samþykkis',
            'categories'     => 'Flokkar',
            'close'          => 'Loka',
            'gpc'            => 'Vafrinn þinn sendir Global Privacy Control (GPC) og því er slökkt á markaðssetningu hér.',
        ),
    );
    return isset( $s[ $lang ] ) ? $s[ $lang ] : $s['en'];
}

// ─────────────────────────────────────────────────────────────────────────────
// Activation / Uninstall
// ─────────────────────────────────────────────────────────────────────────────

register_activation_hook( __FILE__, 'cortiq_activate' );
function cortiq_activate() {
    $existing = get_option( CORTIQ_OPTION_KEY, array() );

    // Migrate legacy ga_measurement_id → ga4_id (class-based plugin versions < 5.1)
    if ( empty( $existing['ga4_id'] ) && ! empty( $existing['ga_measurement_id'] ) ) {
        $existing['ga4_id'] = $existing['ga_measurement_id'];
        unset( $existing['ga_measurement_id'] );
    }

    update_option( CORTIQ_OPTION_KEY, wp_parse_args( $existing, cortiq_defaults() ) );
}

register_uninstall_hook( __FILE__, 'cortiq_uninstall' );
function cortiq_uninstall() {
    delete_option( CORTIQ_OPTION_KEY );
}

// ─────────────────────────────────────────────────────────────────────────────
// Frontend: enqueue tracking scripts
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'wp_enqueue_scripts', 'cortiq_enqueue' );
function cortiq_enqueue() {
    $opts = cortiq_options();

    if ( empty( $opts['tracking_enabled'] ) ) return;
    if ( empty( $opts['site_id'] ) ) return;

    // Skip excluded roles
    if ( is_user_logged_in() ) {
        $user  = wp_get_current_user();
        $roles = (array) $opts['excluded_roles'];
        if ( array_intersect( $roles, (array) $user->roles ) ) return;
    }

    // spa-tracking.js is the unified script:
    // Heatmaps · Sessions · AI Agent Detection · Bot Tracking · Citations · UTM/Paid Ads
    // Served from this site (assets/cortiq.js, bundled at build time), so loading the page makes no
    // request to cortiq.se. The script itself still waits for analytics consent before collecting.
    // No fallback to cortiq.se: the bundled copy is the only code this plugin runs on the site, so a
    // compromised CDN cannot reach WordPress installs. A missing file means a broken install.
    $local = plugin_dir_path( __FILE__ ) . 'assets/cortiq.js';
    if ( ! file_exists( $local ) ) return;
    wp_enqueue_script(
        'cortiq-tracking',
        plugins_url( 'assets/cortiq.js', __FILE__ ),
        array(),
        CORTIQ_VERSION,
        false // load in <head>, defer added via filter below
    );

    // spa-tracking.js reads window.cortiqConfig (NOT data-* attributes) — inject it
    // BEFORE the script tag so siteId/apiKey are available when the script runs.
    // siteId/apiKey are the CortIQ account credentials; the visited site is resolved
    // server-side by domain, so one account key serves all of the account's sites.
    $config = wp_json_encode( array(
        'apiUrl'      => CORTIQ_API,
        'siteId'      => $opts['site_id'],
        'apiKey'      => $opts['tracking_id'],
        'contentType' => 'page',
        'platform'    => 'web',
        // Cookieless mode: no fingerprint and no cross-visit profile. Like everything
        // in spa-tracking.js (including in-browser bot detection) it waits for consent.
        'cookieless'  => ( 'cookieless' === $opts['tracking_mode'] ),
        // Cookieless keeps the session id in sessionStorage after consent (one visit per tab);
        // memory-only writes nothing, and every full page load starts a new visit.
        'sessionStorage' => ! ( 'cookieless' === $opts['tracking_mode'] && ! empty( $opts['cookieless_memory_only'] ) ),
        'aggregate'   => ! empty( $opts['aggregate'] ),
    ) );
    wp_add_inline_script( 'cortiq-tracking', 'window.cortiqConfig = ' . $config . ';', 'before' );

    // Aggregate measurement: counts page views, sources and form goals without consent —
    // no cookies, no device storage, no identifiers. Only when the site owner enabled it.
    if ( ! empty( $opts['aggregate'] ) ) {
        $agg = plugin_dir_path( __FILE__ ) . 'assets/cortiq-aggregate.js';
        if ( file_exists( $agg ) ) {
            wp_enqueue_script( 'cortiq-aggregate', plugins_url( 'assets/cortiq-aggregate.js', __FILE__ ), array(), CORTIQ_VERSION, false );
            wp_add_inline_script( 'cortiq-aggregate', 'window.cortiqConfig = ' . $config . ';', 'before' );
        }
    }

    add_filter( 'script_loader_tag', 'cortiq_add_script_attrs', 10, 2 );
}

function cortiq_add_script_attrs( $tag, $handle ) {
    if ( 'cortiq-tracking' !== $handle && 'cortiq-aggregate' !== $handle ) return $tag;
    // Config travels via window.cortiqConfig (injected above, 'before'); just defer the load —
    // both the tracker and the aggregate beacon still see it since the inline script prints first.
    return str_replace( ' src=', ' defer src=', $tag );
}

// ─────────────────────────────────────────────────────────────────────────────
// Server-side agent measurement (no client code, no device access)
// ─────────────────────────────────────────────────────────────────────────────

function cortiq_server_side_active( $opts ) {
    // tk_… for new sites; some existing sites have an older 44-char base64 key.
    return ! empty( $opts['server_side'] ) && strlen( trim( (string) $opts['tracking_id'] ) ) >= 20;
}

// The CortIQ Cloudflare Worker already reported this request (it adds this header).
function cortiq_reported_at_edge() {
    return ! empty( $_SERVER['HTTP_X_CORTIQ_EDGE'] );
}

function cortiq_truncate_ip( $ip ) {
    $ip = trim( (string) $ip );
    if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
        $o = explode( '.', $ip );
        return $o[0] . '.' . $o[1] . '.' . $o[2] . '.0';
    }
    if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6 ) ) {
        // Keep the first 48 bits; inet_pton handles compressed forms like 2001:db8::1.
        return inet_ntop( substr( inet_pton( $ip ), 0, 6 ) . str_repeat( "\0", 10 ) );
    }
    return null;
}

function cortiq_request_path() {
    $uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
    return (string) wp_parse_url( $uri, PHP_URL_PATH );
}

// Sec-GPC: 1 – CortIQ treats it as an objection (GDPR art. 21(5)); the hit is not sent.
function cortiq_gpc() {
    return isset( $_SERVER['HTTP_SEC_GPC'] ) && sanitize_text_field( wp_unslash( $_SERVER['HTTP_SEC_GPC'] ) ) === '1';
}

function cortiq_report_request( $opts, $status ) {
    if ( cortiq_gpc() ) return;
    $host = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';
    $hit  = array(
        'url'       => ( is_ssl() ? 'https' : 'http' ) . '://' . $host . cortiq_request_path(),
        'method'    => isset( $_SERVER['REQUEST_METHOD'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) : 'GET',
        'status'    => (int) $status,
        'userAgent' => isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ), 0, 512 ) : '',
        'referrer'  => cortiq_clean_referrer(),
        'ip'        => cortiq_truncate_ip( isset( $_SERVER['REMOTE_ADDR'] ) ? wp_unslash( $_SERVER['REMOTE_ADDR'] ) : '' ),
    );
    $GLOBALS['cortiq_pending_hit'] = array( $opts['tracking_id'], $hit );
    if ( ! has_action( 'shutdown', 'cortiq_send_pending_hit' ) ) {
        add_action( 'shutdown', 'cortiq_send_pending_hit', 1 );
    }
}

// Origin + path only: referrer query strings can carry tokens, emails or search terms.
function cortiq_clean_referrer() {
    if ( empty( $_SERVER['HTTP_REFERER'] ) ) return null;
    $parts = wp_parse_url( wp_unslash( $_SERVER['HTTP_REFERER'] ) );
    if ( empty( $parts['scheme'] ) || empty( $parts['host'] ) ) return null;
    $port = isset( $parts['port'] ) ? ':' . (int) $parts['port'] : '';
    return esc_url_raw( $parts['scheme'] . '://' . $parts['host'] . $port . ( isset( $parts['path'] ) ? $parts['path'] : '/' ) );
}

// Sent after the response: the visitor (bot) gets the page first, the report follows.
function cortiq_send_pending_hit() {
    if ( empty( $GLOBALS['cortiq_pending_hit'] ) ) return;
    list( $key, $hit ) = $GLOBALS['cortiq_pending_hit'];
    unset( $GLOBALS['cortiq_pending_hit'] );
    if ( function_exists( 'fastcgi_finish_request' ) ) {
        fastcgi_finish_request();
    }
    wp_remote_post( CORTIQ_API . '/server-hit', array(
        'blocking' => true,
        'timeout'  => 2,
        'headers'  => array( 'Content-Type' => 'application/json', 'Authorization' => 'Bearer ' . $key ),
        'body'     => wp_json_encode( array( 'hits' => array( $hit ) ) ),
    ) );
}

// Runs for normal pages, 404s and WordPress' virtual robots.txt / llms.txt.
add_action( 'template_redirect', 'cortiq_server_side_measure', 0 );
function cortiq_server_side_measure() {
    $opts = cortiq_options();
    if ( empty( $opts['tracking_enabled'] ) || ! cortiq_server_side_active( $opts ) ) return;

    $path = strtolower( cortiq_request_path() );
    $trap = ( $path === rtrim( CORTIQ_TRAP_PATH, '/' ) || 0 === strpos( $path, CORTIQ_TRAP_PATH ) );
    // The Cloudflare Worker reports (and answers the trap) itself; don't count twice.
    if ( cortiq_reported_at_edge() && ! $trap ) return;
    $ua   = isset( $_SERVER['HTTP_USER_AGENT'] ) ? wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : '';

    if ( $trap ) {
        if ( ! cortiq_reported_at_edge() ) cortiq_report_request( $opts, 404 );
        status_header( 404 );
        nocache_headers();
        header( 'X-Robots-Tag: noindex, nofollow' );
        echo 'Not found';
        exit;
    }

    $watched = in_array( $path, array( '/robots.txt', '/llms.txt', '/llms-full.txt' ), true );
    if ( $watched || preg_match( CORTIQ_AGENT_UA, $ua ) ) {
        cortiq_report_request( $opts, is_404() ? 404 : 200 );
    }
}

// Hidden honeypot link in the server-rendered HTML; robots.txt tells crawlers to skip it,
// so only bots that ignore robots.txt follow it. Only when WordPress serves robots.txt
// itself — a physical robots.txt file bypasses the filter below, and without the Disallow
// rule compliant crawlers would follow the link. The Worker injects its own link.
add_action( 'wp_footer', 'cortiq_honeypot_link', 1 );
function cortiq_honeypot_link() {
    $opts = cortiq_options();
    if ( empty( $opts['tracking_enabled'] ) || ! cortiq_server_side_active( $opts ) ) return;
    if ( cortiq_reported_at_edge() || file_exists( ABSPATH . 'robots.txt' ) ) return;
    echo '<a href="' . esc_url( home_url( CORTIQ_TRAP_PATH ) ) . '" rel="nofollow" tabindex="-1" aria-hidden="true" style="position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden">.</a>';
}

add_filter( 'robots_txt', 'cortiq_robots_txt', 20 );
function cortiq_robots_txt( $output ) {
    $opts = cortiq_options();
    if ( ! cortiq_server_side_active( $opts ) || false !== strpos( $output, 'Disallow: ' . CORTIQ_TRAP_PATH ) ) return $output;
    // A crawler obeys only its own user-agent group, so add the rule to every group.
    $rule   = 'Disallow: ' . CORTIQ_TRAP_PATH;
    $lines  = preg_split( '/\r?\n/', (string) $output );
    $out    = array();
    $groups = 0;
    foreach ( $lines as $i => $line ) {
        $out[] = $line;
        $is_ua   = (bool) preg_match( '/^\s*user-agent\s*:/i', $line );
        $next_ua = isset( $lines[ $i + 1 ] ) && preg_match( '/^\s*user-agent\s*:/i', $lines[ $i + 1 ] );
        if ( $is_ua && ! $next_ua ) { $out[] = $rule; $groups++; }
    }
    if ( $groups ) return implode( "\n", $out );
    return rtrim( $output ) . "\n\nUser-agent: *\n" . $rule . "\n";
}

// ─────────────────────────────────────────────────────────────────────────────
// Cookie consent banner
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'wp_footer', 'cortiq_cookie_banner', 100 );
function cortiq_cookie_banner() {
    $opts = cortiq_options();
    if ( empty( $opts['gdpr_enabled'] ) ) return;
    $accent = $opts['accent_color'] ? esc_attr( $opts['accent_color'] ) : '#6366f1';
    $t      = cortiq_banner_strings( cortiq_banner_lang( $opts ) );
    ?>
<style>
#cq-overlay,#cq-reopen{--cq-accent:<?php echo $accent; ?>}
#cq-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:99998;align-items:flex-end;justify-content:center;padding:0}
#cq-box{background:#1e1e2e;color:#e2e8f0;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;font-size:14px;width:100%;max-width:640px;border-radius:12px 12px 0 0;border-top:1px solid var(--cq-accent);box-shadow:0 -8px 40px rgba(0,0,0,.5);max-height:90vh;overflow-y:auto;position:relative}
.cq-close{position:absolute;top:8px;right:10px;background:none;border:none;color:#94a3b8;font-size:22px;line-height:1;cursor:pointer;padding:4px 9px;font-family:inherit;z-index:1;border-radius:6px}
.cq-close:hover{color:#e2e8f0;background:#2d2d45}
#cq-box h2{margin:0;font-size:16px;font-weight:700;color:#e2e8f0;padding-right:28px}
#cq-box p{margin:8px 0 0;font-size:13px;color:#94a3b8;line-height:1.5}
.cq-head{padding:20px 20px 12px}
.cq-cats{padding:0 20px}
.cq-cat{display:flex;align-items:flex-start;gap:12px;padding:12px 0;border-top:1px solid #2d2d45}
.cq-cat-info{flex:1}
.cq-cat-name{font-weight:600;font-size:13px;color:#e2e8f0}
.cq-cat-desc{font-size:12px;color:#64748b;margin-top:2px}
.cq-toggle{position:relative;width:40px;height:22px;flex-shrink:0;margin-top:1px}
.cq-toggle input{opacity:0;width:0;height:0;position:absolute}
.cq-slider{position:absolute;inset:0;border-radius:22px;background:#374151;cursor:pointer;transition:.2s}
.cq-slider:before{content:'';position:absolute;width:16px;height:16px;left:3px;top:3px;border-radius:50%;background:#fff;transition:.2s}
.cq-toggle input:checked+.cq-slider{background:var(--cq-accent)}
.cq-toggle input:checked+.cq-slider:before{transform:translateX(18px)}
.cq-toggle input:disabled+.cq-slider{opacity:.5;cursor:not-allowed}
.cq-details-toggle{display:flex;align-items:center;gap:6px;background:none;border:none;color:var(--cq-accent);font-size:12px;cursor:pointer;padding:10px 20px 4px;font-family:inherit}
.cq-details{display:none;margin:0 20px 12px;padding:12px;background:#161625;border-radius:8px;font-size:12px;color:#64748b;border:1px solid #2d2d45}
.cq-details dt{color:#94a3b8;font-weight:600;margin-top:8px}
.cq-details dt:first-child{margin-top:0}
.cq-details dd{margin:2px 0 0;word-break:break-all;color:#6b7280}
.cq-btns{display:flex;flex-wrap:wrap;gap:8px;padding:16px 20px 20px;border-top:1px solid #2d2d45}
.cq-btn{flex:1;min-width:120px;padding:10px 16px;border-radius:8px;font-size:13px;font-weight:600;cursor:pointer;border:none;font-family:inherit}
.cq-btn-primary{background:var(--cq-accent);color:#fff}
.cq-btn-primary:hover{filter:brightness(.92)}
.cq-btn-secondary{background:#1e293b;color:#94a3b8;border:1px solid #374151}
.cq-btn-secondary:hover{color:#e2e8f0;border-color:var(--cq-accent)}
#cq-reopen{display:none;position:fixed;bottom:20px;left:20px;z-index:99997;width:26px;height:26px;border-radius:50%;border:none;background:var(--cq-accent);color:#fff;cursor:pointer;font-size:16px;line-height:26px;text-align:center;padding:0;box-shadow:0 1px 4px rgba(0,0,0,.3);opacity:.92;font-family:inherit}
#cq-reopen:hover{opacity:1}
/* Minimal-consent state: a hollow pill with a small label — a discreet, STATIC (no
   animation, no red dot) invitation to reconsider. Full consent stays a plain icon. */
#cq-reopen.cq-min{width:auto;height:auto;min-width:26px;border-radius:16px;padding:6px 12px;background:transparent;border:1.5px solid var(--cq-accent);color:var(--cq-accent);opacity:.85;font-size:14px;line-height:1}
#cq-reopen.cq-min:hover{opacity:1}
#cq-reopen .cq-reopen-label{display:none}
#cq-reopen.cq-min .cq-reopen-label{display:inline;margin-left:6px;font-size:13px;font-weight:600;vertical-align:middle}
</style>

<div id="cq-overlay">
  <div id="cq-box" role="dialog" aria-modal="true" aria-label="<?php echo esc_attr( $t['title'] ); ?>">
    <button class="cq-close" id="cq-close" type="button" aria-label="<?php echo esc_attr( $t['close'] ); ?>" title="<?php echo esc_attr( $t['close'] ); ?>">&times;</button>
    <div class="cq-head">
      <h2><?php echo esc_html( $t['title'] ); ?></h2>
      <p><?php echo esc_html( $t['intro'] ); ?></p>
    </div>

    <div class="cq-cats">
      <div class="cq-cat">
        <div class="cq-cat-info">
          <div class="cq-cat-name"><?php echo esc_html( $t['necessary'] ); ?></div>
          <div class="cq-cat-desc"><?php echo esc_html( $t['necessary_desc'] ); ?></div>
        </div>
        <label class="cq-toggle"><input type="checkbox" id="cq-necessary" checked disabled><span class="cq-slider"></span></label>
      </div>
      <div class="cq-cat">
        <div class="cq-cat-info">
          <div class="cq-cat-name"><?php echo esc_html( $t['preferences'] ); ?></div>
          <div class="cq-cat-desc"><?php echo esc_html( $t['preferences_desc'] ); ?></div>
        </div>
        <label class="cq-toggle"><input type="checkbox" id="cq-preferences"><span class="cq-slider"></span></label>
      </div>
      <div class="cq-cat">
        <div class="cq-cat-info">
          <div class="cq-cat-name"><?php echo esc_html( $t['statistics'] ); ?></div>
          <div class="cq-cat-desc"><?php echo esc_html( $t['statistics_desc'] ); ?></div>
        </div>
        <label class="cq-toggle"><input type="checkbox" id="cq-analytics"><span class="cq-slider"></span></label>
      </div>
      <div class="cq-cat">
        <div class="cq-cat-info">
          <div class="cq-cat-name"><?php echo esc_html( $t['marketing'] ); ?></div>
          <div class="cq-cat-desc"><?php echo esc_html( $t['marketing_desc'] ); ?></div>
          <div class="cq-cat-desc" id="cq-gpc-note" style="display:none"><?php echo esc_html( $t['gpc'] ); ?></div>
        </div>
        <label class="cq-toggle"><input type="checkbox" id="cq-marketing"><span class="cq-slider"></span></label>
      </div>
    </div>

    <button class="cq-details-toggle" id="cq-details-toggle" type="button">▸ <span><?php echo esc_html( $t['show_details'] ); ?></span></button>
    <dl class="cq-details" id="cq-details"></dl>

    <div class="cq-btns">
      <button class="cq-btn cq-btn-primary" id="cq-accept-all"><?php echo esc_html( $t['accept_all'] ); ?></button>
      <button class="cq-btn cq-btn-secondary" id="cq-reject"><?php echo esc_html( $t['only_necessary'] ); ?></button>
      <button class="cq-btn cq-btn-secondary" id="cq-save"><?php echo esc_html( $t['save'] ); ?></button>
    </div>
  </div>
</div>

<button id="cq-reopen" title="<?php echo esc_attr( $t['reopen'] ); ?>">🍪<span class="cq-reopen-label">Cookies</span></button>

<script>
(function(){
  var CQ_API = '<?php echo esc_js( CORTIQ_API ); ?>';
  var CQ_GEO = '<?php echo esc_js( CORTIQ_GEO_API ); ?>';
  // Through the CortIQ geo Worker (signed country); direct if it fails.
  function cqFetch(path, init){
    init = Object.assign({}, init, { credentials: 'omit' });
    var direct = function(){ CQ_GEO = CQ_API; return fetch(CQ_API + path, init); };
    if (CQ_GEO === CQ_API) { return fetch(CQ_API + path, init); }
    return fetch(CQ_GEO + path, init).then(function(r){ return r.headers.get('x-cortiq-geo-proxy') === 'error' ? direct() : r; }, direct);
  }
  var CQ_SITE_ID = '<?php echo esc_js( $opts['site_id'] ); ?>';
  var CQ_TRACKING_ID = '<?php echo esc_js( $opts['tracking_id'] ); ?>';
  var CQ_T = <?php echo wp_json_encode( array(
    'show'  => $t['show_details'], 'hide' => $t['hide_details'],
    'nec'   => $t['necessary'],    'pref' => $t['preferences'],
    'stat'  => $t['statistics'],   'mark' => $t['marketing'],
    'cdate' => $t['consent_date'], 'cid'  => $t['consent_id'], 'cats' => $t['categories'],
    'gpc'   => $t['gpc'],
  ) ); ?>;
  var POLICY_VERSION = '<?php echo esc_js( $opts['policy_version'] ); ?>';
  var MAX_AGE = <?php echo max( 1, intval( $opts['reprompt_cooldown_days'] ) ); ?>*24*60*60*1000; // re-ask after an accepted choice
  var MAX_AGE_REJECT = <?php echo max( 1, intval( $opts['reprompt_reject_days'] ) ); ?>*24*60*60*1000; // re-ask after necessary-only
  function ageFor(c){ return (c && (c.preferences || c.analytics || c.marketing)) ? MAX_AGE : MAX_AGE_REJECT; }
  var GEO_GATING = <?php echo ! empty( $opts['geo_gating'] ) ? 'true' : 'false'; ?>;
  var KEY = 'site_cookie_consent';
  var overlay = document.getElementById('cq-overlay');
  var chkPref = document.getElementById('cq-preferences');
  var chkAnal = document.getElementById('cq-analytics');
  var chkMark = document.getElementById('cq-marketing');
  var details = document.getElementById('cq-details');
  var reopen  = document.getElementById('cq-reopen');
  var dToggle = document.getElementById('cq-details-toggle');
  var locale  = (navigator.language || 'sv');

  // Global Privacy Control (spec 2026-11-18 AC6): marketing stays refused while GPC is on.
  var GPC = navigator.globalPrivacyControl === true;
  function tz(){ try { return Intl.DateTimeFormat().resolvedOptions().timeZone || ''; } catch(e){ return ''; } }
  if (GPC) {
    chkMark.checked = false; chkMark.disabled = true;
    var gpcNote = document.getElementById('cq-gpc-note'); if (gpcNote) { gpcNote.style.display = 'block'; }
  }

  function genId(){
    var arr=new Uint8Array(33);
    (window.crypto||window.msCrypto).getRandomValues(arr);
    return btoa(String.fromCharCode.apply(null,arr)).replace(/[+/]/g,function(c){return c==='+'?'-':'_'}).substring(0,44)+'==';
  }

  function fmt(ts){
    var d=new Date(ts);
    try { return d.toLocaleDateString(locale,{day:'numeric',month:'short',year:'numeric'})+' '+d.toLocaleTimeString(locale); }
    catch(e){ return d.toISOString(); }
  }

  // Reopen icon: hollow when the visitor is on necessary-only — a soft, non-nagging cue
  // that they can reconsider, without pulsing dots or notification badges.
  function iconState(c){
    var full = c && (c.preferences || c.analytics || c.marketing);
    reopen.className = full ? '' : 'cq-min';
  }

  function save(pref,anal,mark){
    if (GPC) { mark = false; }
    var now=Date.now();
    // spa-tracking.js only honours a stored choice with a future expiresAt.
    var c={ necessary:true, preferences:pref, analytics:anal, marketing:mark,
      timestamp:now, expiresAt:new Date(now+(pref||anal||mark ? MAX_AGE : MAX_AGE_REJECT)).toISOString(),
      consentId:genId(), policyVersion:POLICY_VERSION };
    try { localStorage.setItem(KEY,JSON.stringify(c)); } catch(e){}
    // GA4 Consent Mode + spa-tracking listen for this event.
    window.dispatchEvent(new CustomEvent('siteConsentUpdated',{detail:c}));
    // GDPR Art. 7: record server-side proof of consent. The backend resolves the site
    // by page domain, so this lands under the right site.
    try {
      cqFetch('/store-consent', {
        method:'POST', headers:{'Content-Type':'application/json'}, keepalive:true,
        body: JSON.stringify({
          site_id: CQ_SITE_ID || undefined, tracking_id: CQ_TRACKING_ID || undefined,
          session_id: c.consentId, page_url: location.href,
          consent_types:{ necessary:true, analytics:anal, marketing:mark, preferences:pref },
          source:'cookie_banner', gpc_signal:GPC, time_zone:tz(),
          policy_version: POLICY_VERSION, locale: locale.substring(0,10)
        })
      }).catch(function(){});
    } catch(e){}
    overlay.style.display='none';
    reopen.style.display='block';
    iconState(c); showDetails(c);
  }

  function showDetails(c){
    if(!c) return;
    var cats = CQ_T.nec
      + (c.preferences?', '+CQ_T.pref:'')
      + (c.analytics?', '+CQ_T.stat:'')
      + (c.marketing?', '+CQ_T.mark:'');
    details.innerHTML =
      '<dt>'+CQ_T.cdate+'</dt><dd>'+fmt(c.timestamp)+'</dd>'+
      '<dt>'+CQ_T.cid+'</dt><dd>'+c.consentId+'</dd>'+
      '<dt>'+CQ_T.cats+'</dt><dd>'+cats+'</dd>';
  }

  if(dToggle){ dToggle.onclick=function(){
    var open=details.style.display==='block';
    details.style.display=open?'none':'block';
    var span=dToggle.querySelector('span'); if(span){ span.textContent=open?CQ_T.show:CQ_T.hide; }
  }; }

  document.getElementById('cq-accept-all').onclick=function(){
    chkPref.checked=true; if(chkAnal){ chkAnal.checked=true; } chkMark.checked=!GPC;
    save(true, !!chkAnal, true);
  };
  document.getElementById('cq-reject').onclick=function(){
    chkPref.checked=false; if(chkAnal){ chkAnal.checked=false; } chkMark.checked=false;
    save(false,false,false);
  };
  document.getElementById('cq-save').onclick=function(){
    save(chkPref.checked, chkAnal?chkAnal.checked:false, chkMark.checked);
  };
  reopen.onclick=function(){ overlay.style.display='flex'; reopen.style.display='none'; };

  // Close (X): dismissing the banner must NOT imply consent (EDPB) — it saves the
  // GDPR-safe default of necessary only, so the banner is answered and won't nag.
  var closeBtn=document.getElementById('cq-close');
  if(closeBtn){ closeBtn.onclick=function(){
    chkPref.checked=false; if(chkAnal){ chkAnal.checked=false; } chkMark.checked=false;
    save(false,false,false);
  }; }

  var existing;
  try{ existing=JSON.parse(localStorage.getItem(KEY)); }catch(e){}
  // Show the banner only if there's no fresh decision. A saved choice (even reject) is
  // respected (accepted: ~12 months, necessary-only: ~6 months by default) — never asked on every visit.
  var fresh = existing && existing.policyVersion===POLICY_VERSION && ((Date.now()-(existing.timestamp||0)) < ageFor(existing));
  // Choices saved by plugin < 5.4.0 have no expiresAt, so spa-tracking.js ignores them.
  // Backfill it here: this footer script runs before the deferred tracker executes.
  if(fresh && !(Date.parse(existing.expiresAt) > Date.now())){
    existing.expiresAt=new Date(existing.timestamp+ageFor(existing)).toISOString();
    try { localStorage.setItem(KEY,JSON.stringify(existing)); } catch(e){}
  }
  function showBanner(){
    if(!GEO_GATING){ overlay.style.display='flex'; return; }
    // Geo-gated: only show inside the EEA/UK/CH; elsewhere no cookie banner is required.
    // Fail-safe: show the banner on any error.
    cqFetch('/geo-check').then(function(r){ return r.json(); }).then(function(g){
      if(g && g.in_scope === false){ reopen.style.display='block'; }
      else { overlay.style.display='flex'; }
    }).catch(function(){ overlay.style.display='flex'; });
  }
  if(!fresh){
    showBanner();
  } else {
    chkPref.checked=!!existing.preferences;
    if(chkAnal){ chkAnal.checked=!!existing.analytics; }
    // GPC: never replay a pre-GPC stored marketing grant anywhere in the UI — checkbox,
    // details list, or reopen icon. Build a masked copy; existing and localStorage are untouched.
    var display = existing;
    if (GPC) {
      display = {};
      for (var k in existing) { if (existing.hasOwnProperty(k)) { display[k] = existing[k]; } }
      display.marketing = false;
    }
    chkMark.checked = !!display.marketing;
    reopen.style.display='block';
    iconState(display); showDetails(display);
  }
})();
</script>
    <?php
}

// ─────────────────────────────────────────────────────────────────────────────
// Google Analytics 4
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'wp_head', 'cortiq_ga4_output', 1 );
function cortiq_ga4_output() {
    $opts = cortiq_options();
    if ( empty( $opts['tracking_enabled'] ) ) return;
    if ( empty( $opts['ga4_id'] ) ) return;

    if ( is_user_logged_in() ) {
        $user  = wp_get_current_user();
        $roles = (array) $opts['excluded_roles'];
        if ( array_intersect( $roles, (array) $user->roles ) ) return;
    }

    $ga4_id   = esc_js( $opts['ga4_id'] );
    $gdpr_on  = ! empty( $opts['gdpr_enabled'] );
    $advanced = ( 'advanced' === $opts['consent_mode'] );
    ?>
<!-- Google Analytics 4 via CortIQ (Consent Mode v2) -->
<script>
(function(){
  window.dataLayer = window.dataLayer || [];
  function gtag(){ dataLayer.push(arguments); }
  window.gtag = window.gtag || gtag;
  var GA_ID    = '<?php echo $ga4_id; ?>';
  var GDPR     = <?php echo $gdpr_on ? 'true' : 'false'; ?>;
  var ADVANCED = <?php echo $advanced ? 'true' : 'false'; ?>;

  if ( GDPR ) {
    // Deny by default until the banner grants consent (Consent Mode v2). All six v2
    // signals; security_storage is always granted (strictly necessary).
    var consentDefaults={ ad_storage:'denied', ad_user_data:'denied', ad_personalization:'denied', analytics_storage:'denied', functionality_storage:'denied', personalization_storage:'denied', security_storage:'granted', wait_for_update:500 };
<?php if ( 'eea' === $opts['consent_region'] ) : ?>
    // Region-scoped: visitors OUTSIDE the EEA/UK/CH are not gated by these defaults.
    consentDefaults.region=['AT','BE','BG','HR','CY','CZ','DK','EE','FI','FR','DE','GR','HU','IS','IE','IT','LV','LI','LT','LU','MT','NL','NO','PL','PT','RO','SK','SI','ES','SE','GB','CH'];
<?php endif; ?>
    gtag('consent','default',consentDefaults);
    gtag('set','ads_data_redaction',true); // redact ad-click IDs while denied
    gtag('set','url_passthrough',true);    // preserve gclid/dclid in URLs without cookies
  }
  gtag('js', new Date());

  var loaded = false;
  function loadGA(){
    if ( loaded ) return; loaded = true;
    gtag('config', GA_ID);
    var s = document.createElement('script');
    s.async = true; s.src = 'https://www.googletagmanager.com/gtag/js?id=' + GA_ID;
    document.head.appendChild(s);
  }
  function hasAnalytics(){
    try { var c = JSON.parse(localStorage.getItem('site_cookie_consent') || 'null'); return !!(c && c.analytics); }
    catch(e){ return false; }
  }

  // Basic (default): GA4 does not load until analytics consent — cleanest legally.
  // Advanced (or GDPR off): GA4 loads now and sends cookieless pings until consent.
  if ( !GDPR || ADVANCED || hasAnalytics() ) {
    loadGA();
    if ( hasAnalytics() ) { gtag('consent','update',{ analytics_storage:'granted' }); }
  }

  window.addEventListener('siteConsentUpdated', function(e){
    var d = e.detail || {};
    gtag('consent','update',{
      analytics_storage: d.analytics ? 'granted' : 'denied',
      ad_storage:        d.marketing ? 'granted' : 'denied',
      ad_user_data:      d.marketing ? 'granted' : 'denied',
      ad_personalization:d.marketing ? 'granted' : 'denied',
      functionality_storage:   d.preferences ? 'granted' : 'denied',
      personalization_storage: d.preferences ? 'granted' : 'denied'
    });
    if ( d.analytics ) { loadGA(); }
  });
})();
</script>
    <?php
}

// ─────────────────────────────────────────────────────────────────────────────
// Admin: settings page
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'admin_menu', 'cortiq_admin_menu' );
function cortiq_admin_menu() {
    add_options_page(
        'CortIQ Analytics',
        'CortIQ Analytics',
        'manage_options',
        'cortiq',
        'cortiq_settings_page'
    );
}

add_action( 'admin_init', 'cortiq_register_settings' );
function cortiq_register_settings() {
    register_setting( 'cortiq_settings_group', CORTIQ_OPTION_KEY, array(
        'sanitize_callback' => 'cortiq_sanitize_options',
    ) );
}

function cortiq_sanitize_options( $input ) {
    $clean                     = cortiq_defaults();
    $clean['site_id']          = isset( $input['site_id'] )
        ? sanitize_text_field( $input['site_id'] ) : '';
    $clean['tracking_id']      = isset( $input['tracking_id'] )
        ? sanitize_text_field( $input['tracking_id'] ) : '';
    $clean['ga4_id']           = isset( $input['ga4_id'] )
        ? sanitize_text_field( $input['ga4_id'] ) : '';
    $clean['tracking_enabled'] = ! empty( $input['tracking_enabled'] );
    $clean['gdpr_enabled']     = ! empty( $input['gdpr_enabled'] );
    $clean['anonymize_ip']     = ! empty( $input['anonymize_ip'] );
    $clean['excluded_roles']   = array( 'administrator' );
    // Validate the banner accent colour; sanitize_hex_color() returns '' if invalid.
    $ac = isset( $input['accent_color'] ) ? sanitize_hex_color( trim( (string) $input['accent_color'] ) ) : '';
    $clean['accent_color']     = $ac ? $ac : '#6366f1';
    $clean['tracking_mode']    = ( isset( $input['tracking_mode'] ) && 'cookieless' === $input['tracking_mode'] ) ? 'cookieless' : 'full';
    $clean['cookieless_memory_only'] = ! empty( $input['cookieless_memory_only'] );
    $bl = isset( $input['banner_language'] ) ? $input['banner_language'] : 'auto';
    $clean['banner_language']  = ( 'auto' === $bl || in_array( $bl, cortiq_banner_languages(), true ) ) ? $bl : 'auto';
    $clean['consent_mode']     = ( isset( $input['consent_mode'] ) && 'advanced' === $input['consent_mode'] ) ? 'advanced' : 'basic';
    $pv = isset( $input['policy_version'] ) ? substr( sanitize_text_field( $input['policy_version'] ), 0, 20 ) : '1';
    $clean['policy_version']   = ( '' !== $pv ) ? $pv : '1';
    $cd = isset( $input['reprompt_cooldown_days'] ) ? intval( $input['reprompt_cooldown_days'] ) : 365;
    $clean['reprompt_cooldown_days'] = ( $cd >= 1 && $cd <= 400 ) ? $cd : 365;
    $rd = isset( $input['reprompt_reject_days'] ) ? intval( $input['reprompt_reject_days'] ) : 180;
    $clean['reprompt_reject_days']   = ( $rd >= 1 && $rd <= 400 ) ? $rd : 180;
    $clean['consent_region']   = ( isset( $input['consent_region'] ) && 'global' === $input['consent_region'] ) ? 'global' : 'eea';
    $clean['geo_gating']       = ! empty( $input['geo_gating'] );
    $clean['server_side']      = ! empty( $input['server_side'] );
    $clean['aggregate']        = ! empty( $input['aggregate'] );
    return $clean;
}

function cortiq_settings_page() {
    if ( ! current_user_can( 'manage_options' ) ) return;
    $opts = cortiq_options();
    ?>
    <div class="wrap">
        <h1 style="display:flex;align-items:center;gap:10px;">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none"
                 stroke="#6366f1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
            </svg>
            CortIQ Analytics
        </h1>

        <?php settings_errors( 'cortiq_settings_group' ); ?>

        <form method="post" action="options.php">
            <?php settings_fields( 'cortiq_settings_group' ); ?>

            <table class="form-table" role="presentation">

                <tr>
                    <th scope="row"><label for="cortiq_site_id">Site ID</label></th>
                    <td>
                        <input id="cortiq_site_id"
                               name="<?php echo CORTIQ_OPTION_KEY; ?>[site_id]"
                               type="text"
                               value="<?php echo esc_attr( $opts['site_id'] ); ?>"
                               class="regular-text"
                               placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx" />
                        <p class="description">
                            UUID from <a href="https://cortiq.se/dashboard" target="_blank">CortIQ Dashboard</a>
                            → Settings → Setup. Used for <strong>AI tracking</strong> (bots, search, citations).
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="cortiq_tracking_id">Tracking ID</label></th>
                    <td>
                        <input id="cortiq_tracking_id"
                               name="<?php echo CORTIQ_OPTION_KEY; ?>[tracking_id]"
                               type="text"
                               value="<?php echo esc_attr( $opts['tracking_id'] ); ?>"
                               class="regular-text"
                               placeholder="tk_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" />
                        <p class="description">
                            tk_xxx key from Dashboard → Settings → Setup. Used for
                            <strong>heatmaps, sessions and page views</strong>.
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">Server-side agent measurement</th>
                    <td>
                        <label>
                            <input type="checkbox" name="<?php echo CORTIQ_OPTION_KEY; ?>[server_side]" value="1"
                                   <?php checked( ! empty( $opts['server_side'] ) ); ?> />
                            Measure AI crawlers and agents on the server
                        </label>
                        <p class="description">
                            Most AI crawlers (GPTBot, ClaudeBot, PerplexityBot…) never run JavaScript. WordPress reports
                            bot/agent requests, <code>robots.txt</code> / <code>llms.txt</code> fetches and hits on a hidden
                            honeypot link to CortIQ, with the IP truncated. Ordinary human page requests are not sent, and a
                            request with Global Privacy Control (<code>Sec-GPC: 1</code>) is not sent either. Nothing runs in
                            the visitor's browser and the consent banner does not control it — mention it in your privacy policy.
                            Requires the Tracking ID above. With full-page caching (or a physical robots.txt file) WordPress
                            doesn't see every request; use the CortIQ Cloudflare Worker for complete coverage.
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="cortiq_ga4_id">Google Analytics 4</label></th>
                    <td>
                        <input id="cortiq_ga4_id"
                               name="<?php echo CORTIQ_OPTION_KEY; ?>[ga4_id]"
                               type="text"
                               value="<?php echo esc_attr( $opts['ga4_id'] ); ?>"
                               class="regular-text"
                               placeholder="G-XXXXXXXXXX" />
                        <p class="description">
                            Your GA4 Measurement ID. Found in
                            <a href="https://analytics.google.com" target="_blank">Google Analytics</a>
                            → Admin → Data Streams → your stream → Measurement ID.
                            Leave empty to disable GA4.
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">Tracking</th>
                    <td>
                        <label>
                            <input type="checkbox"
                                   name="<?php echo CORTIQ_OPTION_KEY; ?>[tracking_enabled]"
                                   value="1"
                                   <?php checked( ! empty( $opts['tracking_enabled'] ) ); ?> />
                            Enable tracking
                        </label>
                    </td>
                </tr>

                <tr>
                    <th scope="row">Privacy</th>
                    <td>
                        <label>
                            <input type="checkbox"
                                   name="<?php echo CORTIQ_OPTION_KEY; ?>[gdpr_enabled]"
                                   value="1"
                                   <?php checked( ! empty( $opts['gdpr_enabled'] ) ); ?> />
                            Show cookie consent banner (GDPR)
                        </label>
                        <p class="description">Uncheck if your theme or another plugin already handles cookie consent.</p>
                        <br>
                        <label>
                            <input type="checkbox"
                                   name="<?php echo CORTIQ_OPTION_KEY; ?>[anonymize_ip]"
                                   value="1"
                                   <?php checked( ! empty( $opts['anonymize_ip'] ) ); ?> />
                            Anonymize IP addresses
                        </label>
                        <br>
                        <label>
                            <input type="checkbox"
                                   name="<?php echo CORTIQ_OPTION_KEY; ?>[geo_gating]"
                                   value="1"
                                   <?php checked( ! empty( $opts['geo_gating'] ) ); ?> />
                            Show the cookie banner only to EEA / UK / Switzerland visitors
                        </label>
                        <p class="description">Visitors outside the EEA/UK/CH won't see the banner. Without a choice, CortIQ visitor analytics stay off for them; AI-agent and bot detection still runs.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">Tracking mode</th>
                    <td>
                        <label style="display:block;margin-bottom:8px">
                            <input type="radio" name="<?php echo CORTIQ_OPTION_KEY; ?>[tracking_mode]" value="cookieless"
                                   <?php checked( 'cookieless', $opts['tracking_mode'] ); ?> />
                            <strong>Cookieless</strong> — privacy-minimised measurement. No cookies, no fingerprint, no cross-visit profile.
                            After consent a session id is kept in sessionStorage for the tab's lifetime.
                            Requires analytics consent (<em>Statistics</em> in the banner).
                        </label>
                        <label style="display:block;margin:0 0 8px 24px">
                            <input type="checkbox" name="<?php echo CORTIQ_OPTION_KEY; ?>[cookieless_memory_only]" value="1"
                                   <?php checked( ! empty( $opts['cookieless_memory_only'] ) ); ?> />
                            Memory only (cookieless): do not store the session id in the browser. Every full page load then counts as a new visit.
                        </label>
                        <label style="display:block">
                            <input type="radio" name="<?php echo CORTIQ_OPTION_KEY; ?>[tracking_mode]" value="full"
                                   <?php checked( 'full', $opts['tracking_mode'] ); ?> />
                            <strong>Full</strong> — device fingerprint + returning-visitor profiling. Requires analytics consent.
                        </label>
                        <p class="description">Both modes need analytics consent before the tracking script does anything, including in-browser bot detection. AI crawlers are measured server-side instead (see Server-side agent measurement).</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">Aggregate measurement</th>
                    <td>
                        <label>
                            <input type="checkbox" name="<?php echo CORTIQ_OPTION_KEY; ?>[aggregate]" value="1" <?php checked( ! empty( $opts['aggregate'] ) ); ?> />
                            Count page views, sources and form goals without consent
                        </label>
                        <p class="description">No cookies, no device storage, no persistent identifiers. Designed to not require consent; your own legal assessment decides. Also switch it on in the CortIQ dashboard (Consent → Tracking mode), otherwise hits are ignored.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="cortiq_banner_language">Banner language</label></th>
                    <td>
                        <select id="cortiq_banner_language" name="<?php echo CORTIQ_OPTION_KEY; ?>[banner_language]">
                            <option value="auto" <?php selected( 'auto', $opts['banner_language'] ); ?>>Auto (WordPress locale)</option>
                            <option value="en"   <?php selected( 'en',   $opts['banner_language'] ); ?>>English</option>
                            <option value="sv"   <?php selected( 'sv',   $opts['banner_language'] ); ?>>Svenska</option>
                            <option value="de"   <?php selected( 'de',   $opts['banner_language'] ); ?>>Deutsch</option>
                            <option value="fr"   <?php selected( 'fr',   $opts['banner_language'] ); ?>>Français</option>
                            <option value="pt"   <?php selected( 'pt',   $opts['banner_language'] ); ?>>Português</option>
                            <option value="nl"   <?php selected( 'nl',   $opts['banner_language'] ); ?>>Nederlands</option>
                            <option value="nb"   <?php selected( 'nb',   $opts['banner_language'] ); ?>>Norsk (bokmål)</option>
                            <option value="da"   <?php selected( 'da',   $opts['banner_language'] ); ?>>Dansk</option>
                            <option value="fi"   <?php selected( 'fi',   $opts['banner_language'] ); ?>>Suomi</option>
                            <option value="pl"   <?php selected( 'pl',   $opts['banner_language'] ); ?>>Polski</option>
                            <option value="it"   <?php selected( 'it',   $opts['banner_language'] ); ?>>Italiano</option>
                            <option value="es"   <?php selected( 'es',   $opts['banner_language'] ); ?>>Español</option>
                            <option value="is"   <?php selected( 'is',   $opts['banner_language'] ); ?>>Íslenska</option>
                        </select>
                        <p class="description">Language for the cookie banner. Auto follows your site's WordPress language.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">GA4 Consent Mode</th>
                    <td>
                        <label style="display:block;margin-bottom:8px">
                            <input type="radio" name="<?php echo CORTIQ_OPTION_KEY; ?>[consent_mode]" value="basic"
                                   <?php checked( 'basic', $opts['consent_mode'] ); ?> />
                            <strong>Basic</strong> — GA4 loads only after the visitor accepts Statistics. Cleanest legally.
                        </label>
                        <label style="display:block">
                            <input type="radio" name="<?php echo CORTIQ_OPTION_KEY; ?>[consent_mode]" value="advanced"
                                   <?php checked( 'advanced', $opts['consent_mode'] ); ?> />
                            <strong>Advanced</strong> — GA4 loads immediately and sends cookieless pings; Google models the gaps.
                        </label>
                        <p class="description">Only affects sites with a GA4 ID.</p>
                    </td>
                </tr>

                <tr>
                    <th scope="row">Consent scope &amp; policy</th>
                    <td>
                        <p style="margin:0 0 10px">
                            <label for="cortiq_consent_region"><strong>Geo scope for consent defaults</strong></label><br>
                            <select id="cortiq_consent_region" name="<?php echo CORTIQ_OPTION_KEY; ?>[consent_region]">
                                <option value="eea"    <?php selected( 'eea',    $opts['consent_region'] ); ?>>EEA + UK + Switzerland (region-scoped)</option>
                                <option value="global" <?php selected( 'global', $opts['consent_region'] ); ?>>Global (apply everywhere)</option>
                            </select>
                            <span class="description"> Region-scoped means visitors outside the EEA/UK/CH aren't gated by Consent Mode defaults.</span>
                        </p>
                        <p style="margin:0 0 10px">
                            <label for="cortiq_policy_version"><strong>Policy version</strong></label><br>
                            <input id="cortiq_policy_version" type="text"
                                   name="<?php echo CORTIQ_OPTION_KEY; ?>[policy_version]"
                                   value="<?php echo esc_attr( $opts['policy_version'] ); ?>" style="max-width:120px" />
                            <span class="description"> Change this to re-prompt every visitor (e.g. after updating your cookie/privacy policy).</span>
                        </p>
                        <p style="margin:0">
                            <label for="cortiq_cooldown"><strong>Re-ask cooldown (days)</strong></label><br>
                            <input id="cortiq_cooldown" type="number" min="1" max="400"
                                   name="<?php echo CORTIQ_OPTION_KEY; ?>[reprompt_cooldown_days]"
                                   value="<?php echo esc_attr( $opts['reprompt_cooldown_days'] ); ?>" style="max-width:90px" />
                            <span class="description"> How long an accepted choice is respected before asking again. Default 365.</span>
                        </p>
                        <p style="margin:0">
                            <label for="cortiq_reject_cooldown"><strong>Re-ask after "necessary only" (days)</strong></label><br>
                            <input id="cortiq_reject_cooldown" type="number" min="1" max="400"
                                   name="<?php echo CORTIQ_OPTION_KEY; ?>[reprompt_reject_days]"
                                   value="<?php echo esc_attr( $opts['reprompt_reject_days'] ); ?>" style="max-width:90px" />
                            <span class="description"> How long a necessary-only choice is respected before asking again. Default 180. Asking on every visit pressures visitors and can make consent invalid.</span>
                        </p>
                    </td>
                </tr>

                <tr>
                    <th scope="row"><label for="cortiq_accent_color">Banner color</label></th>
                    <td>
                        <input id="cortiq_accent_color"
                               name="<?php echo CORTIQ_OPTION_KEY; ?>[accent_color]"
                               type="text"
                               value="<?php echo esc_attr( $opts['accent_color'] ); ?>"
                               style="max-width:110px;vertical-align:middle"
                               placeholder="#6366f1" />
                        <input type="color" id="cortiq_accent_picker"
                               value="<?php echo esc_attr( $opts['accent_color'] ); ?>"
                               style="vertical-align:middle;width:40px;height:30px;padding:0;border:1px solid #ccc;border-radius:4px;cursor:pointer" />
                        <span style="display:inline-flex;gap:6px;margin-left:12px;vertical-align:middle">
                            <?php foreach ( array( '#6366f1', '#0ea5e9', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#111827' ) as $c ) : ?>
                                <button type="button" class="cortiq-swatch" data-color="<?php echo esc_attr( $c ); ?>"
                                        title="<?php echo esc_attr( $c ); ?>"
                                        style="width:22px;height:22px;border-radius:50%;border:1px solid rgba(0,0,0,.2);background:<?php echo esc_attr( $c ); ?>;cursor:pointer;padding:0"></button>
                            <?php endforeach; ?>
                        </span>
                        <p class="description">Accent colour for the cookie banner and the reopen button. Pick a preset, use the colour picker, or type any hex value.</p>
                        <script>
                        (function(){
                            var txt  = document.getElementById('cortiq_accent_color');
                            var pick = document.getElementById('cortiq_accent_picker');
                            if ( pick ) pick.addEventListener('input', function(){ txt.value = pick.value; });
                            document.querySelectorAll('.cortiq-swatch').forEach(function(b){
                                b.addEventListener('click', function(){
                                    var v = b.getAttribute('data-color');
                                    txt.value = v;
                                    try { pick.value = v; } catch(e){}
                                });
                            });
                        })();
                        </script>
                    </td>
                </tr>

            </table>

            <?php submit_button( 'Save Settings' ); ?>
        </form>

        <hr>
        <h2>Status</h2>
        <table class="widefat" style="max-width:520px;">
            <tbody>
                <tr>
                    <td><strong>Version</strong></td>
                    <td><?php echo esc_html( CORTIQ_VERSION ); ?></td>
                </tr>
                <tr>
                    <td><strong>Site ID</strong></td>
                    <td>
                        <?php if ( ! empty( $opts['site_id'] ) ) : ?>
                            <span style="color:green">&#10003; Configured</span>
                            &nbsp;<code><?php echo esc_html( $opts['site_id'] ); ?></code>
                        <?php else : ?>
                            <span style="color:#d63638">&#10007; Not set</span>
                            <span style="color:#777"> — AI tracking disabled</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td><strong>Tracking ID</strong></td>
                    <td>
                        <?php if ( ! empty( $opts['tracking_id'] ) ) : ?>
                            <span style="color:green">&#10003; Configured</span>
                            &nbsp;<code><?php echo esc_html( $opts['tracking_id'] ); ?></code>
                        <?php else : ?>
                            <span style="color:#d63638">&#10007; Not set</span>
                            <span style="color:#777"> — heatmaps/sessions disabled</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td><strong>Google Analytics 4</strong></td>
                    <td>
                        <?php if ( ! empty( $opts['ga4_id'] ) ) : ?>
                            <span style="color:green">&#10003; Active</span>
                            &nbsp;<code><?php echo esc_html( $opts['ga4_id'] ); ?></code>
                        <?php else : ?>
                            <span style="color:#777">Not configured</span>
                        <?php endif; ?>
                    </td>
                </tr>
                <tr>
                    <td><strong>Tracking</strong></td>
                    <td>
                        <?php echo ! empty( $opts['tracking_enabled'] )
                            ? '<span style="color:green">&#10003; Active</span>'
                            : '<span style="color:gray">Paused</span>'; ?>
                    </td>
                </tr>
            </tbody>
        </table>

        <hr>
        <h2>Script loaded</h2>
        <table class="widefat" style="max-width:520px;">
            <thead><tr><th>Script</th><th>Covers</th><th>Status</th></tr></thead>
            <tbody>
                <tr>
                    <td><code>spa-tracking.js</code></td>
                    <td>Heatmaps · Sessions · AI Agents · Bots · Citations · UTM</td>
                    <td>
                        <?php echo ! empty( $opts['site_id'] ) && ! empty( $opts['tracking_enabled'] )
                            ? '<span style="color:green">&#10003; Active</span>'
                            : '<span style="color:#d63638">Needs Site ID</span>'; ?>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <?php
}

// ─────────────────────────────────────────────────────────────────────────────
// Admin notice: missing IDs
// ─────────────────────────────────────────────────────────────────────────────

add_action( 'admin_notices', 'cortiq_admin_notice' );
function cortiq_admin_notice() {
    if ( ! current_user_can( 'manage_options' ) ) return;
    $screen = get_current_screen();
    if ( $screen && $screen->id === 'settings_page_cortiq' ) return;

    $opts = cortiq_options();
    if ( ! empty( $opts['site_id'] ) ) return;

    $url = admin_url( 'options-general.php?page=cortiq' );
    echo '<div class="notice notice-warning is-dismissible"><p>'
        . '<strong>CortIQ Analytics:</strong> '
        . 'Add your Site ID to enable tracking. '
        . '<a href="' . esc_url( $url ) . '">Go to settings &rarr;</a>'
        . '</p></div>';
}
